/*global enyo:false */
enyo.depends(
	'app.js'
);
