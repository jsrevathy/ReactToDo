(ns todomvc.components.title)

(defn component []
  [:h1 "todos"])
